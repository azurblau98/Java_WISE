package org.json.junit.data;

public class MyLocaleBean {
    private final String id = "beanId";
    private final String i = "beanI";
    public String getId() {
        return this.id;
    }
    public String getI() {
        return this.i;
    }
}
